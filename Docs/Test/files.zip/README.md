# 🔍 LABA ERP - AI CHECK & FIX PROMPTS

## Quick Reference

Use these prompts to have AI check data integrity and fix sync issues.

---

## 📁 AVAILABLE PROMPTS

| Module | File | Key Checks |
|--------|------|------------|
| **AR/AP** | `CHECK_FIX_AR_AP.md` | Transaction↔AR/AP sync, Partner balance, Payment flow |
| **Inventory** | `CHECK_FIX_INVENTORY.md` | Product↔Stock sync, StockMovement, COGS calculation |
| **Payroll** | `CHECK_FIX_PAYROLL.md` | Net amount, Insurance 10.5%, PIT, Payroll→Transaction |
| **VAT** | `CHECK_FIX_VAT.md` | VAT rates, Input/Output, Cash≥20M, Declarations |
| **CIT** | `CHECK_FIX_CIT.md` | Add-backs, Vehicle cap, Penalty 100%, Welfare cap |

---

## 🚀 HOW TO USE

### Step 1: Copy the prompt
Open the relevant `.md` file and copy entire content.

### Step 2: Give to AI
Paste into AI chat with your codebase context.

### Step 3: AI will
1. Read service files to understand implementation
2. Query database for mismatches
3. Fix issues found
4. Report results

---

## 🔄 COMMON SYNC ISSUES

### The "INCOME only" Bug Pattern
Many services only check one trans_type instead of both:

```typescript
// ❌ BUG (found in multiple places)
trans_type: 'INCOME'
trans_type: 'EXPENSE'

// ✓ CORRECT
trans_type: { in: ['SALE', 'INCOME'] }
trans_type: { in: ['PURCHASE', 'EXPENSE'] }
```

**Affected:** AR service, AP service, Reports, Dashboard

### The "Payment Not Synced" Bug Pattern
Payment updates one table but not others:

```
Payment made
  ├── ✓ PaymentHistory created
  ├── ✓ PaymentAllocation created  
  ├── ✓ AR/APTransaction.balance updated
  ├── ❌ Transaction.paid_amount NOT updated
  └── ❌ Partner.balance NOT updated
```

### The "Stock Not Synced" Bug Pattern
Transaction updates Product but not Stock:

```
SALE created
  ├── ✓ Transaction created
  ├── ✓ TransactionItems created
  ├── ✓ Product.stock_qty updated
  ├── ❌ Stock.quantity NOT updated
  └── ❌ StockMovement NOT created
```

---

## 📊 EXPECTED OUTPUT FORMAT

All prompts follow this output format:

```
📊 [MODULE] CHECK RESULTS
=========================
✓ Check passed: Details
✗ Check failed: X issues found
⚠ Warning: Something to review

🔧 FIXES APPLIED
================
- Record X: field old_value → new_value
- Created missing record Y
- Updated Z records
```

---

## 🏃 RUN ORDER

For full system check, run in this order:

1. **AR/AP** - Foundation for partner balances
2. **Inventory** - Stock sync and COGS
3. **Payroll** - Employee payments
4. **VAT** - Tax calculations
5. **CIT** - Corporate tax and add-backs

---

## 📝 ADDING NEW PROMPTS

Template structure:

```markdown
# AI PROMPT: CHECK & FIX [MODULE] MODULE

## YOUR TASK
One-line description.

## CONTEXT
- Stack info
- File locations
- Table names

## RULES TO CHECK
Numbered list of business rules with formulas.

## WHAT TO CHECK
Specific checks with SQL examples.

## COMMON BUGS
Code examples of bugs to find.

## FIX PATTERNS
Code examples of how to fix.

## OUTPUT FORMAT
Expected output template.
```

---

## ✅ VALIDATION

After running fixes, verify with health-check:

```bash
npx tsx scripts/health-check.ts
```

All checks should pass! 🎉
