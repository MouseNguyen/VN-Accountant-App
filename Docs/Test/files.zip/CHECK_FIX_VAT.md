# AI PROMPT: CHECK & FIX VAT MODULE

## YOUR TASK
Check VAT calculation integrity and fix issues in Vietnamese farm ERP.

## CONTEXT
- Stack: Next.js + Prisma + PostgreSQL
- Location: `src/services/vat.service.ts`, `src/services/tax.service.ts`
- Tables: `transactions`, `transaction_items`, `vat_declarations`

## VIETNAM VAT RULES TO CHECK

### 1. VAT Rates
| Type | Rate |
|------|------|
| Standard | 10% (was 8% during COVID relief) |
| Reduced | 5% (agriculture, medical, education) |
| Zero | 0% (exports) |
| Exempt | N/A (land, finance, healthcare) |

### 2. Output VAT (VAT bán ra)
From SALE/INCOME transactions:
```
output_vat = SUM(transaction_items.vat_amount) 
           WHERE trans_type IN ('SALE', 'INCOME')
```

### 3. Input VAT (VAT mua vào) - Deductible
From PURCHASE/EXPENSE with valid invoice:
```
input_vat = SUM(transaction_items.vat_amount)
          WHERE trans_type IN ('PURCHASE', 'EXPENSE')
          AND has_valid_invoice = true
          AND is_deductible = true
```

### 4. Non-Deductible VAT Rules
VAT **CANNOT** be deducted if:
- Cash payment >= 20,000,000 VND (must use bank transfer)
- No valid VAT invoice
- Personal expenses (không phục vụ SXKD)
- Vehicle purchase > 1.6 billion (capped)

Check: Cash PURCHASE >= 20M marked as non-deductible?

### 5. VAT Payable
```
vat_payable = output_vat - input_vat_deductible
```
If negative → VAT refund or carry forward

### 6. VAT Declaration Sync
VATDeclaration record should match:
- `output_vat` = SUM from SALE/INCOME in period
- `input_vat` = SUM from PURCHASE/EXPENSE in period
- `vat_payable` = output - input

### 7. Item-Level VAT Calculation
```
item.vat_amount = item.line_total × (item.vat_rate / 100)
item.line_total = item.quantity × item.unit_price - item.discount
```

## WHAT TO CHECK

1. **Item VAT calculation**: vat_amount = line_total × rate/100?
2. **Transaction VAT sum**: tax_amount = SUM(items.vat_amount)?
3. **Cash >= 20M**: Marked non-deductible?
4. **Declaration totals**: Match transaction sums for period?
5. **trans_type coverage**: Output includes SALE+INCOME? Input includes PURCHASE+EXPENSE?

## COMMON BUGS TO FIND

```typescript
// BUG: Only checking INCOME, missing SALE
WHERE trans_type = 'INCOME'  // ❌
WHERE trans_type IN ('SALE', 'INCOME')  // ✓

// BUG: Not checking payment method for deductibility
// Should check: payment_method !== 'CASH' OR total < 20M

// BUG: Rounding issues
// VND should have 0 decimal places
```

## FIX PATTERNS

```typescript
// Fix non-deductible flag
if (trans.payment_method === 'CASH' && trans.total_amount >= 20000000) {
  await prisma.transaction.update({
    where: { id: trans.id },
    data: { is_vat_deductible: false }
  });
}

// Fix declaration totals
await prisma.vATDeclaration.update({
  where: { id: declaration.id },
  data: {
    output_vat: calculatedOutput,
    input_vat: calculatedInput,
    vat_payable: calculatedOutput - calculatedInput
  }
});
```

## OUTPUT FORMAT
```
📊 VAT CHECK RESULTS
====================
✓ Item VAT calculations: 150/150 correct
✗ Cash >= 20M non-deductible: 3 not flagged
✓ Declaration Q4/2024: Totals match
⚠ trans_type query: Using INCOME only (missing SALE)

🔧 FIXES APPLIED
================
- Transaction MH-001: is_vat_deductible → false (cash 25M)
- VATDeclaration Q4: output_vat 15,000,000 → 18,500,000
```
