# AI PROMPT: CHECK & FIX PAYROLL MODULE

## YOUR TASK
Check data integrity and fix sync issues in Payroll module for Vietnamese farm ERP.

## CONTEXT
- Stack: Next.js + Prisma + PostgreSQL
- Location: `src/services/payroll.service.ts`, `src/services/worker.service.ts`
- Tables: `workers`, `payrolls`, `payroll_items`, `worker_advances`, `transactions`

## KNOWN PATTERNS TO CHECK

### 1. Net Amount Calculation
```
net_amount = gross_amount - insurance_employee - pit_amount - total_deductions + total_allowances
```
Check: PayrollItem.net_amount matches formula?

### 2. Insurance Rates (Vietnam)
Employee pays: BHXH 8% + BHYT 1.5% + BHTN 1% = **10.5%**
Employer pays: BHXH 17.5% + BHYT 3% + BHTN 1% = **21.5%**

Check: `insurance_employee` ≈ `gross_amount × 0.105`?

### 3. PIT Calculation (Progressive rates)
| Income (VND/month) | Rate |
|-------------------|------|
| 0 - 5M | 5% |
| 5M - 10M | 10% |
| 10M - 18M | 15% |
| 18M - 32M | 20% |
| 32M - 52M | 25% |
| 52M - 80M | 30% |
| > 80M | 35% |

Taxable = Gross - Insurance - Personal Deduction (11M) - Dependents (4.4M each)

### 4. Payroll → Transaction Sync
When payroll is PAID:
- Should create EXPENSE transaction with `expense_type: 'SALARY'`
- Transaction.total_amount = SUM(payroll_items.net_amount)

Check: Paid Payroll has matching Transaction?

### 5. Worker Advance → Deduction Sync
WorkerAdvance with `is_deducted: false` should be included in PayrollItem.total_deductions

Check: Pending advances are deducted in next payroll?

### 6. Payroll Status Flow
DRAFT → APPROVED → PAID
- DRAFT: Can edit
- APPROVED: Cannot edit, ready to pay
- PAID: Creates transaction, marks items `is_paid: true`

## WHAT TO DO

1. **Read** the service files to understand current implementation
2. **Query** database to find mismatches:
   - PayrollItem.net_amount ≠ calculated
   - Insurance rate ≠ 10.5%
   - PAID payroll without Transaction
   - Advances not deducted
3. **Fix** by updating records or creating missing links
4. **Report** what was found and fixed

## EXAMPLE FIX PATTERNS

```typescript
// Fix net_amount
const calculated = gross - insurance - pit - deductions + allowances;
if (Math.abs(item.net_amount - calculated) > 1) {
  await prisma.payrollItem.update({
    where: { id: item.id },
    data: { net_amount: calculated }
  });
}

// Create missing transaction for PAID payroll
if (payroll.status === 'PAID' && !linkedTransaction) {
  await prisma.transaction.create({
    data: {
      farm_id: payroll.farm_id,
      trans_type: 'EXPENSE',
      expense_type: 'SALARY',
      total_amount: totalNet,
      paid_amount: totalNet,
      payment_status: 'PAID',
      // ...
    }
  });
}
```

## OUTPUT FORMAT
```
📊 PAYROLL CHECK RESULTS
========================
✓ Net calculations: X/Y correct
✗ Insurance rates: Found Z mismatches
✓ Payroll-Transaction sync: All OK
⚠ Worker advances: 2 not deducted

🔧 FIXES APPLIED
================
- PayrollItem #123: net_amount 8,500,000 → 8,450,000
- Created Transaction for Payroll PRL-2025-01
```
