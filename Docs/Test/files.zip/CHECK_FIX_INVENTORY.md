# AI PROMPT: CHECK & FIX INVENTORY & COGS MODULE

## YOUR TASK
Check inventory sync and COGS calculation for Vietnamese farm ERP.

## CONTEXT
- Stack: Next.js + Prisma + PostgreSQL
- Location: `src/services/inventory.service.ts`, `src/services/stock.service.ts`
- Tables: `products`, `stocks`, `stock_movements`, `transactions`, `transaction_items`
- Method: **Moving Average Cost**

## MOVING AVERAGE FORMULA

```
new_avg_cost = (old_qty × old_avg_cost + new_qty × new_price) / (old_qty + new_qty)
```

When stock OUT:
```
COGS = quantity_out × avg_cost_at_time
```

## DATA SYNC RULES

### 1. Product.stock_qty = SUM(Stock.quantity)
```sql
-- Check mismatch
SELECT p.id, p.name, p.stock_qty as product_qty,
       COALESCE(SUM(s.quantity), 0) as stock_qty
FROM products p
LEFT JOIN stocks s ON p.id = s.product_id
GROUP BY p.id
HAVING p.stock_qty != COALESCE(SUM(s.quantity), 0);
```

### 2. Stock.quantity = SUM(StockMovement IN) - SUM(StockMovement OUT)
```sql
SELECT s.id, s.quantity as stock_qty,
  SUM(CASE WHEN sm.type IN ('IN','ADJUSTMENT_IN') THEN sm.quantity ELSE 0 END) -
  SUM(CASE WHEN sm.type IN ('OUT','ADJUSTMENT_OUT') THEN sm.quantity ELSE 0 END) as calc_qty
FROM stocks s
LEFT JOIN stock_movements sm ON s.product_id = sm.product_id
GROUP BY s.id
HAVING s.quantity != calculated;
```

### 3. Transaction SALE → Stock OUT + StockMovement
When SALE transaction created:
- Stock.quantity should DECREASE
- StockMovement type='OUT' should be created
- COGS should be calculated and stored

### 4. Transaction PURCHASE → Stock IN + StockMovement
When PURCHASE transaction created:
- Stock.quantity should INCREASE
- Stock.avg_cost should be recalculated (moving average)
- StockMovement type='IN' should be created

## COMMON BUGS TO FIND

### Bug 1: Transaction only updates Product, not Stock
```typescript
// BUG: Only updates Product.stock_qty
await prisma.product.update({
  data: { stock_qty: { decrement: qty } }
});
// Missing: Stock.quantity update
// Missing: StockMovement creation
```

### Bug 2: COGS not calculated
```typescript
// BUG: COGS field is always 0
// Should be: qty × avg_cost at time of sale
```

### Bug 3: StockMovement not created for transactions
```typescript
// BUG: No audit trail for inventory changes from sales
```

## WHAT TO CHECK

1. **Product vs Stock qty**: Do they match?
2. **Stock vs StockMovement**: Reconciliation correct?
3. **SALE creates StockMovement OUT?**: Check for missing movements
4. **PURCHASE creates StockMovement IN?**: Check for missing movements
5. **COGS populated?**: StockMovement.cogs_amount > 0 for OUT?
6. **Avg cost updated?**: Stock.avg_cost recalculated on IN?

## FIX PATTERNS

```typescript
// Fix 1: Sync Product.stock_qty from Stock
const stockSum = await prisma.stock.aggregate({
  where: { product_id: productId },
  _sum: { quantity: true }
});
await prisma.product.update({
  where: { id: productId },
  data: { stock_qty: stockSum._sum.quantity || 0 }
});

// Fix 2: Create missing StockMovement for SALE
const saleItems = await prisma.transactionItem.findMany({
  where: { transaction: { trans_type: 'SALE' } },
  include: { product: { include: { stocks: true } } }
});

for (const item of saleItems) {
  const existingMovement = await prisma.stockMovement.findFirst({
    where: { transaction_id: item.transaction_id, product_id: item.product_id }
  });
  
  if (!existingMovement) {
    const avgCost = item.product.stocks[0]?.avg_cost || item.unit_cost || 0;
    await prisma.stockMovement.create({
      data: {
        product_id: item.product_id,
        transaction_id: item.transaction_id,
        type: 'OUT',
        quantity: item.quantity,
        unit_cost: avgCost,
        cogs_amount: item.quantity * avgCost,
        // ...
      }
    });
  }
}

// Fix 3: Recalculate COGS for existing movements
await prisma.stockMovement.updateMany({
  where: { type: 'OUT', cogs_amount: 0 },
  data: { cogs_amount: prisma.raw('quantity * unit_cost') }
});
```

## OUTPUT FORMAT
```
📊 INVENTORY CHECK RESULTS
==========================
✗ Product vs Stock sync: 5 products mismatch
✗ SALE → StockMovement: 12 transactions missing OUT movement
✓ PURCHASE → StockMovement: All OK
✗ COGS calculation: 8 movements have cogs_amount = 0

🔧 FIXES APPLIED
================
- Product SKU-001: stock_qty 100 → 85 (synced from Stock)
- Created 12 StockMovement OUT records
- Updated COGS for 8 movements
- Total COGS added: 15,500,000đ
```
