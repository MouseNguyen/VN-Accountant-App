# AI PROMPT: CHECK & FIX AR/AP (Receivables/Payables) MODULE

## YOUR TASK
Check AR/AP sync with Transactions and Partner balances for Vietnamese farm ERP.

## CONTEXT
- Stack: Next.js + Prisma + PostgreSQL
- Location: `src/services/ar.service.ts`, `src/services/ap.service.ts`, `src/services/payable.service.ts`
- Tables: `transactions`, `ar_transactions`, `ap_transactions`, `partners`, `payment_histories`, `payment_allocations`

## DATA RELATIONSHIPS

```
Transaction (SALE/INCOME) → ARTransaction → Partner (CUSTOMER)
Transaction (PURCHASE/EXPENSE) → APTransaction → Partner (VENDOR)
Payment → PaymentHistory → PaymentAllocation → Updates all above
```

## SYNC RULES TO CHECK

### 1. Transaction → AR/AP Creation
```
SALE/INCOME with partner + unpaid → Should have ARTransaction
PURCHASE/EXPENSE with partner + unpaid → Should have APTransaction
```

### 2. Balance Consistency
```
ARTransaction.balance = Transaction.total_amount - Transaction.paid_amount
APTransaction.balance = Transaction.total_amount - Transaction.paid_amount
Partner.balance = SUM(outstanding from related transactions)
```

### 3. Payment Flow
When payment made:
1. PaymentHistory created
2. PaymentAllocation links to transaction(s)
3. Transaction.paid_amount increases
4. AR/APTransaction.balance decreases
5. Partner.balance decreases

### 4. trans_type Coverage
```typescript
// AR should include:
trans_type IN ('SALE', 'INCOME')  // ✓

// AP should include:
trans_type IN ('PURCHASE', 'EXPENSE')  // ✓

// COMMON BUG:
trans_type = 'INCOME'  // ❌ Missing SALE
trans_type = 'EXPENSE'  // ❌ Missing PURCHASE
```

## WHAT TO CHECK

### Check 1: Missing AR/AP records
```sql
-- Unpaid SALE/INCOME without AR record
SELECT t.* FROM transactions t
LEFT JOIN ar_transactions ar ON ar.transaction_id = t.id
WHERE t.trans_type IN ('SALE', 'INCOME')
AND t.payment_status != 'PAID'
AND t.partner_id IS NOT NULL
AND ar.id IS NULL;

-- Unpaid PURCHASE/EXPENSE without AP record
SELECT t.* FROM transactions t
LEFT JOIN ap_transactions ap ON ap.transaction_id = t.id
WHERE t.trans_type IN ('PURCHASE', 'EXPENSE')
AND t.payment_status != 'PAID'
AND t.partner_id IS NOT NULL
AND ap.id IS NULL;
```

### Check 2: Balance mismatch
```sql
-- AR balance mismatch
SELECT ar.code, ar.balance as ar_balance,
       (t.total_amount - t.paid_amount) as trans_balance
FROM ar_transactions ar
JOIN transactions t ON ar.transaction_id = t.id
WHERE ABS(ar.balance - (t.total_amount - t.paid_amount)) > 1;
```

### Check 3: Partner balance mismatch
```sql
-- Partner balance vs sum of outstanding
SELECT p.id, p.name, p.balance as stored,
  SUM(CASE 
    WHEN t.trans_type IN ('SALE','INCOME') AND p.partner_type='CUSTOMER' 
    THEN t.total_amount - t.paid_amount
    WHEN t.trans_type IN ('PURCHASE','EXPENSE') AND p.partner_type='VENDOR'
    THEN t.total_amount - t.paid_amount
    ELSE 0
  END) as calculated
FROM partners p
LEFT JOIN transactions t ON t.partner_id = p.id AND t.deleted_at IS NULL
GROUP BY p.id
HAVING ABS(p.balance - calculated) > 1;
```

### Check 4: Payment not synced to Transaction
```sql
-- Transaction.paid_amount doesn't match PaymentAllocation sum
SELECT t.code, t.paid_amount as trans_paid,
       COALESCE(SUM(pa.amount), 0) as allocation_sum
FROM transactions t
LEFT JOIN payment_allocations pa ON pa.transaction_id = t.id
WHERE t.partner_id IS NOT NULL
GROUP BY t.id
HAVING ABS(t.paid_amount - COALESCE(SUM(pa.amount), 0)) > 1;
```

## COMMON BUGS

```typescript
// BUG 1: AR service only queries INCOME
const receivables = await prisma.aRTransaction.findMany({
  where: { transaction: { trans_type: 'INCOME' } }  // ❌ Missing SALE
});

// BUG 2: AP service only queries EXPENSE  
const payables = await prisma.aPTransaction.findMany({
  where: { transaction: { trans_type: 'EXPENSE' } }  // ❌ Missing PURCHASE
});

// BUG 3: Payment updates AR/AP but not Transaction.paid_amount
// BUG 4: Payment updates Transaction but not Partner.balance
```

## FIX PATTERNS

```typescript
// Fix 1: Create missing AR records
const missingSales = await findUnpaidWithoutAR();
for (const trans of missingSales) {
  await prisma.aRTransaction.create({
    data: {
      farm_id: trans.farm_id,
      transaction_id: trans.id,
      partner_id: trans.partner_id,
      type: 'INVOICE',
      amount: trans.total_amount,
      balance: trans.total_amount - trans.paid_amount,
      paid_amount: trans.paid_amount,
      due_date: trans.due_date,
      status: trans.paid_amount >= trans.total_amount ? 'PAID' : 
              trans.paid_amount > 0 ? 'PARTIAL' : 'UNPAID'
    }
  });
}

// Fix 2: Sync AR/AP balance from Transaction
await prisma.aRTransaction.updateMany({
  where: { transaction_id: transId },
  data: { 
    balance: trans.total_amount - trans.paid_amount,
    paid_amount: trans.paid_amount,
    status: calculateStatus(trans)
  }
});

// Fix 3: Sync Transaction.paid_amount from PaymentAllocation
const allocSum = await prisma.paymentAllocation.aggregate({
  where: { transaction_id: transId },
  _sum: { amount: true }
});
await prisma.transaction.update({
  where: { id: transId },
  data: { 
    paid_amount: allocSum._sum.amount || 0,
    payment_status: calculateStatus(trans.total_amount, allocSum._sum.amount)
  }
});

// Fix 4: Sync Partner.balance from Transactions
const outstanding = await calculatePartnerOutstanding(partnerId);
await prisma.partner.update({
  where: { id: partnerId },
  data: { balance: outstanding }
});
```

## OUTPUT FORMAT
```
📊 AR/AP CHECK RESULTS
======================
✗ Missing AR records: 5 unpaid SALE transactions
✗ Missing AP records: 3 unpaid PURCHASE transactions
✗ AR balance mismatch: 2 records
✓ AP balance mismatch: All OK
✗ Partner balance mismatch: 4 partners
✗ Transaction.paid_amount sync: 6 transactions

🔧 FIXES APPLIED
================
- Created 5 AR records for SALE transactions
- Created 3 AP records for PURCHASE transactions
- Synced AR balance for 2 records
- Fixed Partner "Đại lý Thuốc BVTV": 2,400,000 → 0
- Synced Transaction.paid_amount for 6 records
```
