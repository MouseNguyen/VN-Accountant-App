# AI PROMPT: CHECK & FIX CIT (Corporate Income Tax) MODULE

## YOUR TASK
Check CIT calculation and add-back rules for Vietnamese farm ERP.

## CONTEXT
- Stack: Next.js + Prisma + PostgreSQL  
- Location: `src/services/tax.service.ts`, `src/services/cit.service.ts`
- Tables: `transactions`, `assets`, `cit_declarations`
- CIT Rate: **20%** (standard Vietnam)

## CIT CALCULATION FORMULA

```
Accounting Profit = Revenue - COGS - Operating Expenses
Taxable Income = Accounting Profit + Add-backs - Deductions
CIT Payable = Taxable Income × 20%
```

## ADD-BACK RULES TO CHECK

### 1. Expenses Without Valid Invoice
Any expense > threshold without VAT invoice must be added back.

```sql
-- Find expenses without invoice
SELECT * FROM transactions 
WHERE trans_type IN ('EXPENSE', 'PURCHASE')
AND (invoice_number IS NULL OR invoice_number = '')
AND total_amount > 0;
```

### 2. Cash Payments >= 20M VND
```sql
SELECT * FROM transactions
WHERE trans_type IN ('EXPENSE', 'PURCHASE')
AND payment_method = 'CASH'
AND total_amount >= 20000000;
```
These are **non-deductible** for CIT.

### 3. Personal Expenses (Không phục vụ SXKD)
Check `expense_type` for non-business expenses:
- `WELFARE` over limit (1 month salary average)
- `ADMIN_PENALTY` (fines, penalties - 100% add-back)
- Personal consumption

### 4. Vehicle Depreciation Cap
Vehicles > 1.6 billion VND:
- Depreciation only deductible up to 1.6B base
- Excess must be added back

```typescript
// Check assets
if (asset.category === 'VEHICLE' && asset.purchase_price > 1600000000) {
  const excessDepreciation = calculateExcessDepreciation(asset);
  addBack += excessDepreciation;
}
```

### 5. Interest Expense Cap
Related-party loans: Interest rate capped at 150% of central bank rate.
Total interest expense: Capped at 30% of EBITDA.

### 6. Advertising/Marketing Cap
Capped at **15%** of total deductible expenses (excluding COGS).

### 7. Welfare Fund Cap
- Employee welfare: Max 1 month average salary per employee
- Excess is add-back

## EXPENSE_TYPE ENUM CHECK

Ensure these are properly classified:
```typescript
enum ExpenseType {
  NORMAL = 'NORMAL',           // Fully deductible
  ADMIN_PENALTY = 'ADMIN_PENALTY', // 100% add-back
  WELFARE = 'WELFARE',         // Capped
  SALARY = 'SALARY',           // Deductible
  UTILITY = 'UTILITY',         // Deductible
  RENT = 'RENT',               // Deductible
  MARKETING = 'MARKETING',     // Capped at 15%
  INTEREST = 'INTEREST',       // Capped
  DEPRECIATION = 'DEPRECIATION' // May have vehicle cap
}
```

## WHAT TO CHECK

1. **Add-back calculation**: All non-deductible items identified?
2. **Cash >= 20M**: Flagged for add-back?
3. **Vehicle depreciation**: Excess added back?
4. **Penalty expenses**: 100% added back?
5. **Welfare cap**: Applied correctly?
6. **CIT Declaration**: Matches calculated taxable income?

## COMMON BUGS

```typescript
// BUG: Not calculating add-backs
taxable_income = accounting_profit; // ❌ Missing add-backs

// BUG: Missing expense_type in P&L grouping
// Should separate deductible vs non-deductible

// BUG: Vehicle cap not applied
depreciation = asset.purchase_price / useful_life; // ❌
// Should cap at 1.6B for vehicles
```

## FIX PATTERNS

```typescript
// Calculate add-backs
let addBacks = 0;

// 1. Cash >= 20M
const cashExpenses = await prisma.transaction.aggregate({
  where: {
    trans_type: { in: ['EXPENSE', 'PURCHASE'] },
    payment_method: 'CASH',
    total_amount: { gte: 20000000 }
  },
  _sum: { total_amount: true }
});
addBacks += Number(cashExpenses._sum.total_amount || 0);

// 2. Penalties
const penalties = await prisma.transaction.aggregate({
  where: { expense_type: 'ADMIN_PENALTY' },
  _sum: { total_amount: true }
});
addBacks += Number(penalties._sum.total_amount || 0);

// 3. Vehicle excess depreciation
for (const vehicle of expensiveVehicles) {
  const actualDep = vehicle.purchase_price / vehicle.useful_life;
  const allowedDep = Math.min(vehicle.purchase_price, 1600000000) / vehicle.useful_life;
  addBacks += actualDep - allowedDep;
}

// Update CIT declaration
await prisma.cITDeclaration.update({
  where: { id: declaration.id },
  data: {
    add_backs: addBacks,
    taxable_income: accountingProfit + addBacks,
    cit_payable: (accountingProfit + addBacks) * 0.20
  }
});
```

## OUTPUT FORMAT
```
📊 CIT CHECK RESULTS
====================
✓ Expense classification: All categorized
✗ Cash >= 20M add-back: 5 transactions missing (45M total)
✗ Vehicle depreciation cap: 2 vehicles over 1.6B
✓ Penalty add-back: 3 items correctly added back

🔧 FIXES APPLIED
================
- CIT Q4/2024: add_backs 0 → 67,500,000
- CIT Q4/2024: taxable_income recalculated
- CIT Q4/2024: cit_payable 15,000,000 → 28,500,000
```
