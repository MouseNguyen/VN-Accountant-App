// ecosystem.config.js
// PM2 Configuration for LABA ERP Health Check
// 
// Usage:
//   pm2 start ecosystem.config.js
//   pm2 start ecosystem.config.js --only health-check
//   pm2 logs health-check
//   pm2 stop health-check

module.exports = {
  apps: [
    // Main Next.js App
    {
      name: 'laba-erp',
      script: 'npm',
      args: 'start',
      cwd: './',
      instances: 1,
      autorestart: true,
      watch: false,
      max_memory_restart: '1G',
      env: {
        NODE_ENV: 'production',
        PORT: 3000,
      },
    },
    
    // Scheduled Health Check
    {
      name: 'health-check',
      script: 'npx',
      args: 'tsx scripts/scheduled-health-check.ts',
      cwd: './',
      instances: 1,
      autorestart: true,
      watch: false,
      max_memory_restart: '500M',
      
      // Cron mode - PM2 built-in cron (alternative to node-cron)
      // Uncomment below to use PM2 cron instead of node-cron
      // cron_restart: '0 6 * * *',
      
      env: {
        NODE_ENV: 'production',
        TZ: 'Asia/Ho_Chi_Minh',
        // Add your notification webhooks here
        // SLACK_WEBHOOK: 'https://hooks.slack.com/services/xxx',
        // ALERT_EMAIL: 'admin@example.com',
      },
      
      // Logging
      error_file: './logs/health-check/pm2-error.log',
      out_file: './logs/health-check/pm2-out.log',
      log_date_format: 'YYYY-MM-DD HH:mm:ss Z',
      merge_logs: true,
    },
    
    // One-time health check (for manual runs)
    {
      name: 'health-check-once',
      script: 'npx',
      args: 'tsx scripts/scheduled-health-check.ts --run-now',
      cwd: './',
      autorestart: false,
      watch: false,
      env: {
        NODE_ENV: 'production',
        TZ: 'Asia/Ho_Chi_Minh',
      },
    },
  ],
};
