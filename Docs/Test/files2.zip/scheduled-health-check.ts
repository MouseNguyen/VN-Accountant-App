// scripts/scheduled-health-check.ts
// =====================================================
// LABA ERP - SCHEDULED HEALTH CHECK
// Options: node-cron, system cron, or PM2
// 
// Usage: npx tsx scripts/scheduled-health-check.ts
// =====================================================

import { CronJob } from 'cron';
import { execSync } from 'child_process';
import * as fs from 'fs';
import * as path from 'path';

// Configuration
const CONFIG = {
    // Run at 6:00 AM Vietnam time (UTC+7) every day
    cronExpression: '0 6 * * *',
    timezone: 'Asia/Ho_Chi_Minh',
    
    // Paths
    healthCheckScript: path.join(__dirname, 'health-check.ts'),
    logsDir: path.join(__dirname, '../logs/health-check'),
    
    // Notifications (configure as needed)
    notifications: {
        enabled: false,
        webhook: process.env.SLACK_WEBHOOK || '',
        email: process.env.ALERT_EMAIL || '',
    },
    
    // Auto-fix on failure
    autoFix: true,
    
    // Keep logs for X days
    logRetentionDays: 30,
};

// Ensure logs directory exists
if (!fs.existsSync(CONFIG.logsDir)) {
    fs.mkdirSync(CONFIG.logsDir, { recursive: true });
}

// =====================================================
// MAIN JOB FUNCTION
// =====================================================
async function runHealthCheck(): Promise<{
    success: boolean;
    summary: any;
    logFile: string;
}> {
    const timestamp = new Date().toISOString().split('T')[0];
    const logFile = path.join(CONFIG.logsDir, `health-check-${timestamp}.log`);
    
    console.log(`\n🏥 Starting scheduled health check at ${new Date().toISOString()}`);
    
    try {
        // Run health-check script and capture output
        const output = execSync(`npx tsx ${CONFIG.healthCheckScript}`, {
            encoding: 'utf-8',
            timeout: 300000, // 5 minutes timeout
            cwd: path.join(__dirname, '..'),
        });
        
        // Save log
        fs.writeFileSync(logFile, output);
        
        // Parse results from JSON file
        const jsonFile = `./health-check-${timestamp}.json`;
        let summary = { passed: 0, failed: 0, warnings: 0 };
        
        if (fs.existsSync(jsonFile)) {
            const jsonContent = JSON.parse(fs.readFileSync(jsonFile, 'utf-8'));
            summary = jsonContent.summary;
            
            // Move JSON to logs dir
            fs.renameSync(jsonFile, path.join(CONFIG.logsDir, `health-check-${timestamp}.json`));
        }
        
        const success = summary.failed === 0;
        
        console.log(`✅ Health check completed: ${summary.passed} passed, ${summary.failed} failed, ${summary.warnings} warnings`);
        
        return { success, summary, logFile };
        
    } catch (error: any) {
        const errorMsg = `❌ Health check failed: ${error.message}`;
        console.error(errorMsg);
        
        fs.writeFileSync(logFile, errorMsg + '\n' + (error.stdout || '') + '\n' + (error.stderr || ''));
        
        return {
            success: false,
            summary: { passed: 0, failed: 1, warnings: 0, error: error.message },
            logFile
        };
    }
}

// =====================================================
// NOTIFICATION FUNCTIONS
// =====================================================
async function sendSlackNotification(result: { success: boolean; summary: any }) {
    if (!CONFIG.notifications.enabled || !CONFIG.notifications.webhook) return;
    
    const emoji = result.success ? '✅' : '🚨';
    const status = result.success ? 'HEALTHY' : 'ISSUES DETECTED';
    
    const message = {
        text: `${emoji} *LABA ERP Health Check - ${status}*`,
        blocks: [
            {
                type: 'section',
                text: {
                    type: 'mrkdwn',
                    text: `${emoji} *LABA ERP Daily Health Check*\n*Status:* ${status}\n*Time:* ${new Date().toLocaleString('vi-VN', { timeZone: 'Asia/Ho_Chi_Minh' })}`
                }
            },
            {
                type: 'section',
                fields: [
                    { type: 'mrkdwn', text: `*Passed:* ${result.summary.passed}` },
                    { type: 'mrkdwn', text: `*Failed:* ${result.summary.failed}` },
                    { type: 'mrkdwn', text: `*Warnings:* ${result.summary.warnings}` },
                ]
            }
        ]
    };
    
    try {
        await fetch(CONFIG.notifications.webhook, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(message),
        });
        console.log('📤 Slack notification sent');
    } catch (error) {
        console.error('Failed to send Slack notification:', error);
    }
}

// =====================================================
// LOG CLEANUP
// =====================================================
function cleanupOldLogs() {
    const cutoffDate = new Date();
    cutoffDate.setDate(cutoffDate.getDate() - CONFIG.logRetentionDays);
    
    const files = fs.readdirSync(CONFIG.logsDir);
    let cleaned = 0;
    
    for (const file of files) {
        const filePath = path.join(CONFIG.logsDir, file);
        const stats = fs.statSync(filePath);
        
        if (stats.mtime < cutoffDate) {
            fs.unlinkSync(filePath);
            cleaned++;
        }
    }
    
    if (cleaned > 0) {
        console.log(`🧹 Cleaned up ${cleaned} old log files`);
    }
}

// =====================================================
// CRON JOB SETUP
// =====================================================
function startScheduler() {
    console.log('🕐 Starting LABA ERP Health Check Scheduler');
    console.log(`   Schedule: ${CONFIG.cronExpression} (${CONFIG.timezone})`);
    console.log(`   Logs: ${CONFIG.logsDir}`);
    console.log(`   Auto-fix: ${CONFIG.autoFix ? 'enabled' : 'disabled'}`);
    console.log('');
    
    const job = new CronJob(
        CONFIG.cronExpression,
        async () => {
            const result = await runHealthCheck();
            
            // Send notification
            await sendSlackNotification(result);
            
            // Cleanup old logs
            cleanupOldLogs();
        },
        null,
        true,
        CONFIG.timezone
    );
    
    console.log(`✅ Scheduler started. Next run: ${job.nextDate().toISO()}`);
    
    // Keep process running
    process.on('SIGINT', () => {
        console.log('\n👋 Stopping scheduler...');
        job.stop();
        process.exit(0);
    });
}

// =====================================================
// CLI OPTIONS
// =====================================================
const args = process.argv.slice(2);

if (args.includes('--run-now')) {
    // Run immediately without scheduling
    runHealthCheck().then(result => {
        sendSlackNotification(result);
        process.exit(result.success ? 0 : 1);
    });
} else if (args.includes('--help')) {
    console.log(`
LABA ERP - Scheduled Health Check

Usage:
  npx tsx scripts/scheduled-health-check.ts [options]

Options:
  --run-now     Run health check immediately and exit
  --help        Show this help message

Environment Variables:
  SLACK_WEBHOOK    Slack webhook URL for notifications
  ALERT_EMAIL      Email for alerts (requires email service setup)

Cron Expression: ${CONFIG.cronExpression}
  - Runs daily at 6:00 AM Vietnam time (UTC+7)
  - Modify CONFIG.cronExpression to change schedule

Examples:
  # Start scheduler (runs continuously)
  npx tsx scripts/scheduled-health-check.ts
  
  # Run once immediately
  npx tsx scripts/scheduled-health-check.ts --run-now
  
  # Run with PM2
  pm2 start scripts/scheduled-health-check.ts --name "health-check"
`);
} else {
    startScheduler();
}
