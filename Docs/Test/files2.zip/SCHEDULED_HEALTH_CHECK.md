# 🕐 LABA ERP - Scheduled Health Check

## Overview

Automated daily health check system with multiple deployment options.

---

## 🚀 Quick Start

### Option 1: Node-Cron (Simplest)

```bash
# Install dependency
npm install cron

# Start scheduler (runs continuously)
npx tsx scripts/scheduled-health-check.ts

# Or run once immediately
npx tsx scripts/scheduled-health-check.ts --run-now
```

### Option 2: PM2 (Recommended for Production)

```bash
# Install PM2 globally
npm install -g pm2

# Start with ecosystem config
pm2 start ecosystem.config.js --only health-check

# View logs
pm2 logs health-check

# Stop
pm2 stop health-check

# Restart
pm2 restart health-check
```

### Option 3: System Cron (Linux/Mac)

```bash
# Make script executable
chmod +x scripts/setup-cron.sh

# Run setup
./scripts/setup-cron.sh

# Or manually add to crontab
crontab -e
# Add: 0 6 * * * /path/to/project/scripts/run-health-check.sh
```

### Option 4: API Endpoint (External Monitoring)

```bash
# Quick check
curl http://localhost:3000/api/health

# Full integrity check
curl http://localhost:3000/api/health?full=true
```

---

## ⏰ Schedule Configuration

Default: **6:00 AM Vietnam time (UTC+7) daily**

### Change Schedule

Edit `scripts/scheduled-health-check.ts`:

```typescript
const CONFIG = {
    cronExpression: '0 6 * * *',  // Change this
    timezone: 'Asia/Ho_Chi_Minh',
    // ...
};
```

### Cron Expression Examples

| Expression | Description |
|------------|-------------|
| `0 6 * * *` | 6:00 AM daily |
| `0 */6 * * *` | Every 6 hours |
| `0 6 * * 1-5` | 6:00 AM weekdays only |
| `0 6,18 * * *` | 6:00 AM and 6:00 PM |
| `*/30 * * * *` | Every 30 minutes |

---

## 📤 Notifications

### Slack Setup

1. Create Slack webhook: https://api.slack.com/messaging/webhooks
2. Set environment variable:

```bash
export SLACK_WEBHOOK="https://hooks.slack.com/services/xxx/yyy/zzz"
```

3. Enable in config:

```typescript
notifications: {
    enabled: true,
    webhook: process.env.SLACK_WEBHOOK,
}
```

### Email Setup (requires additional setup)

```bash
export ALERT_EMAIL="admin@yourcompany.com"
```

---

## 📁 Log Files

Location: `logs/health-check/`

| File | Description |
|------|-------------|
| `health-check-YYYY-MM-DD.log` | Daily console output |
| `health-check-YYYY-MM-DD.json` | Detailed JSON results |
| `cron.log` | System cron output |
| `pm2-out.log` | PM2 stdout |
| `pm2-error.log` | PM2 stderr |

### Log Retention

Default: **30 days**

Change in config:
```typescript
logRetentionDays: 30,
```

---

## 🔍 API Endpoint Details

### GET /api/health

Quick health check (< 1 second)

**Response:**
```json
{
    "status": "healthy",
    "timestamp": "2025-01-15T06:00:00.000Z",
    "checks": {
        "database": true,
        "tables": true
    },
    "version": "1.0.0",
    "uptime": 86400
}
```

### GET /api/health?full=true

Full integrity check (may take 10-30 seconds)

**Response:**
```json
{
    "status": "degraded",
    "timestamp": "2025-01-15T06:00:00.000Z",
    "checks": {
        "database": true,
        "tables": true,
        "integrity": {
            "partners": { "ok": 45, "issues": 2 },
            "stock": { "ok": 120, "issues": 0 },
            "transactions": { "ok": 500, "issues": 3 }
        }
    },
    "version": "1.0.0",
    "uptime": 86400
}
```

### Status Codes

| Status | Code | Meaning |
|--------|------|---------|
| healthy | 200 | All checks passed |
| degraded | 200 | Minor issues (< 10) |
| unhealthy | 503 | Critical issues |

---

## 🔧 Integration with Monitoring Services

### UptimeRobot

1. Add new monitor
2. Monitor Type: HTTP(s)
3. URL: `https://your-domain.com/api/health`
4. Monitoring Interval: 5 minutes

### Pingdom

1. Add new Uptime check
2. Check type: HTTP
3. URL: `https://your-domain.com/api/health`
4. Check interval: 1 minute

### Datadog

```yaml
# datadog.yaml
instances:
  - name: laba-erp-health
    url: https://your-domain.com/api/health
    method: GET
    timeout: 10
```

---

## 📊 What Gets Checked

| Category | Checks |
|----------|--------|
| **Database** | Connection, Tables exist |
| **Data Integrity** | Partner balance, Stock sync, AP/AR balance, Payment status |
| **Calculations** | Moving average, VND rounding, Item formulas |
| **Transactions** | Type counts, AR/AP queries |
| **Reports** | Revenue, Expense, COGS |
| **VAT** | VAT transactions, Cash ≥20M, Declarations |
| **Fixed Assets** | Asset count, Vehicle cap |
| **Audit Trail** | Log entries, Hash chain |
| **Business Rules** | Negative stock, Future dates |
| **Payroll** | Active workers, Pending payroll |

---

## 🛠️ Troubleshooting

### Scheduler not running

```bash
# Check if process is running
ps aux | grep scheduled-health-check

# Check PM2 status
pm2 status

# Check cron logs
tail -f /var/log/cron
```

### Database connection issues

```bash
# Test database connection
npx tsx -e "const { prisma } = require('./src/lib/prisma'); prisma.\$queryRaw\`SELECT 1\`.then(console.log)"
```

### Permission issues (cron)

```bash
# Check script permissions
ls -la scripts/run-health-check.sh

# Make executable
chmod +x scripts/run-health-check.sh
```

---

## 📝 Files Created

| File | Purpose |
|------|---------|
| `scripts/scheduled-health-check.ts` | Main scheduler with node-cron |
| `scripts/setup-cron.sh` | System cron setup script |
| `scripts/run-health-check.sh` | Cron runner script (auto-generated) |
| `ecosystem.config.js` | PM2 configuration |
| `src/app/api/health/route.ts` | API endpoint |
