-- AlterTable
ALTER TABLE "invoices" ADD COLUMN     "expires_at" TIMESTAMP(3);
