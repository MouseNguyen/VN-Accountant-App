-- AlterTable
ALTER TABLE "transaction_items" ALTER COLUMN "product_name" SET DEFAULT '',
ALTER COLUMN "sub_total" SET DEFAULT 0,
ALTER COLUMN "total" SET DEFAULT 0;
