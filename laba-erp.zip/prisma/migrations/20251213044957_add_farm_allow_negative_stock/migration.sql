-- AlterTable
ALTER TABLE "farms" ADD COLUMN     "allow_negative_stock" BOOLEAN NOT NULL DEFAULT false;
