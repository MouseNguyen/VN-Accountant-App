-- AlterTable
ALTER TABLE "invoices" ADD COLUMN     "image_hash" TEXT;
