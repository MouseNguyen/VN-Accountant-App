-- AlterEnum
ALTER TYPE "InvoiceStatus" ADD VALUE 'CONFIRMED';
