-- AlterTable
ALTER TABLE "invoices" ADD COLUMN     "error_message" TEXT;
