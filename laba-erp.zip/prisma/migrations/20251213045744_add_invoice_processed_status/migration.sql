-- AlterEnum
ALTER TYPE "InvoiceStatus" ADD VALUE 'PROCESSED';
