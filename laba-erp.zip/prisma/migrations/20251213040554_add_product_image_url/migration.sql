-- AlterTable
ALTER TABLE "products" ADD COLUMN     "image_url" TEXT;
