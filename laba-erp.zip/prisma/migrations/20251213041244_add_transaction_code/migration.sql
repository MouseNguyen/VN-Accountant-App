-- AlterTable
ALTER TABLE "transactions" ADD COLUMN     "code" TEXT;
