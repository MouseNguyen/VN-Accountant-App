-- AlterTable
ALTER TABLE "partners" ADD COLUMN     "notes" TEXT;
